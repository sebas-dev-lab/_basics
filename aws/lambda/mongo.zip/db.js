const mongoose = require("mongoose");

let conn = null;

const uri = `mongodb+srv://wallet:fayser17@cluster0.f812g.mongodb.net/wallet?retryWrites=true&w=majority`;

exports.connect = async function () {
  if (conn == null) {
    conn = mongoose
      .connect(uri, {
        serverSelectionTimeoutMS: 5000,
      })
      .then(() => mongoose);
    await conn;
  }
  return conn;
};
