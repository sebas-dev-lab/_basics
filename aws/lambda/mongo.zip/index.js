const mongoose = require("mongoose");
const { connect } = require("./db");
const User = require("./models/User");

exports.handler = async function (event, context) {
  context.callbackWaitsForEmptyEventLoop = false;
  connect();
  //   mongoose.model("wallets", new mongoose.Schema({ name: String }));
  let newUser1 = new User({ name: "name1" });
  let newUser2 = new User({ name: "name2" });
  let newUser3 = new User({ name: "name3" });

  await newUser1.save();
  await newUser2.save();
  await newUser3.save();

  let users = await User.find();
  console.log(users);

  return users;
};
